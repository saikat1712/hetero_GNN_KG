## Contributing to OpenHGNN

Contribution is always welcomed. Please feel free to open an issue or email to tyzhao@bupt.edu.cn.

## Contributors

- **[GAMMA LAB](https://github.com/BUPT-GAMMA) [BUPT]**
  
  Core Developer
  
  - [Tianyu Zhao](https://github.com/Theheavens)
  - Hongyi Zhang
  - Yaoqi Liu
  - Hui Han
  
  Model Implementation
  
  - Nian Liu
  - Siyong Xu
  - Zhiyuan Lu
  - Fengqi Liang
  - Yibo Li
  - Yanhu Mo
  - Donglin Xia
  - Xinlong Zhai
  - Siyuan Zhang
  - Qi Zhang
  
  Advisor
  
  - [Chuan Shi](http://shichuan.org/)
  - Cheng Yang
  - Xiao Wang

- **BUPT**
  
  - Jiahang Li
  - Anke Hu

- **DGL Team**
  
  - Quan Gan
  - Minjie Wang
  - [Jian Zhang](https://github.com/zhjwy9343)

- **Peng Cheng Laboratory**
  
  - Fangqing Jiang
  - Hui Wang
