.. _api-model:

Models
=========

.. currentmodule:: openhgnn.models

.. autosummary::
    :nosignatures:
    {% for cls in openhgnn.models.classes %}
      {{ cls }}
    {% endfor %}

.. automodule:: openhgnn.models
    :members:
    :exclude-members:
