Layer
=======

.. currentmodule:: openhgnn.layers

.. autosummary::
    :nosignatures:
    {% for cls in openhgnn.layers.classes %}
      {{ cls }}
    {% endfor %}

.. automodule:: openhgnn.layers
    :members:
    :exclude-members: