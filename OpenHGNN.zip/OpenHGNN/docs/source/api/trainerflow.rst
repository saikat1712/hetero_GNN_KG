.. _api-trainerflow:

Trainerflow
=================================

.. currentmodule:: openhgnn.trainerflow

.. autosummary::
    :nosignatures:
    {% for cls in openhgnn.trainerflow.classes %}
      {{ cls }}
    {% endfor %}

.. automodule:: openhgnn.trainerflow
    :members:
    :exclude-members: