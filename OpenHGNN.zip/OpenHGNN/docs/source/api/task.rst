.. _api-task:

Task
=================================

.. currentmodule:: openhgnn.tasks

.. autosummary::
    :nosignatures:
    {% for cls in openhgnn.tasks.classes %}
      {{ cls }}
    {% endfor %}

.. automodule:: openhgnn.tasks
    :members:
    :exclude-members: