#!/bin/sh

make clean
rm -rf build
rm -rf source/_build