from .ATTConv import ATTConv, MacroConv
from .SemanticConv import SemanticAttention